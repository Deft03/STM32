#include "main.h"
void LCD_put(uint8_t ch) ;
void LCD_cmd(uint8_t ch) ;
void LCD_print(uint8_t *s) ;
void LCD_CGRAM(uint8_t *s, uint8_t pos) ;
void LCD_put4bit(uint8_t ch) ;
void LCD_init(void) ;
